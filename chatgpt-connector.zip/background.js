importScripts('protocol.js');
const P=MetaAIProtocol;
const getJob=async()=> (await chrome.storage.session.get('job')).job || null;
const save=job=>chrome.storage.session.set({job});
async function notify(job,type,extra={}) {try{await chrome.tabs.sendMessage(job.webTab,{channel:'META_AI_EVENT',type,id:job.id,...extra});}catch{/* Kết quả vẫn giữ trong session để trang khôi phục khi tải lại. */}}
async function finish(job,error='') {
  job.status=error?'error':'done';job.error=error;job.updatedAt=Date.now();await save(job);
  await notify(job,'RESULT',{posts:job.posts||[],error});
}
async function handle(m,sender) {
  const fromWeb=P.website(sender.url),fromGPT=(()=>{try{return new URL(sender.url).origin==='https://chatgpt.com';}catch{return false;}})();
  if(m?.type==='STATUS'&&fromWeb){const job=await getJob();return {ok:true,version:'1.0.12',job:job?.webTab===sender.tab.id?{id:job.id,status:job.status,posts:job.posts||[],error:job.error||'',progress:job.progress||'',reviewKey:job.pendingCommit||'',diagnostic:job.diagnostic||null}:null};}
  if(m?.type==='GENERATE'&&fromWeb){
    const existing=await getJob();
    if(existing&&['opening','running'].includes(existing.status))throw Error('Đang có một lượt tạo bài. Hãy chờ hoàn tất hoặc bấm Dừng.');
    if(!/^ai-[a-zA-Z0-9_-]{1,90}$/.test(m.id))throw Error('Mã yêu cầu không hợp lệ.');
    const input=P.validate(m.payload);
    const job={id:m.id,nonce:crypto.randomUUID(),webTab:sender.tab.id,gptTab:null,input,posts:[],status:'opening',progress:'Đang mở ChatGPT…',updatedAt:Date.now()};
    await save(job);
    try{const tab=await chrome.tabs.create({url:'https://chatgpt.com/',active:true});job.gptTab=tab.id;await save(job);}catch(e){await finish(job,'Không mở được tab ChatGPT.');throw e;}
    return {ok:true,id:job.id};
  }
  if(m?.type==='DRAFT_SAVED'&&fromWeb){const job=await getJob();if(!job||job.webTab!==sender.tab.id||job.id!==m.payload?.jobId||!['opening','running'].includes(job.status)||!job.pendingCommit||job.pendingCommit!==m.payload?.key)throw Error('Xác nhận lưu bài không hợp lệ.');job.reviewSaved=job.pendingCommit;await save(job);return {ok:true};}
  if(m?.type==='CANCEL'&&fromWeb){const job=await getJob();if(job?.webTab===sender.tab.id&&['opening','running'].includes(job.status)){job.status='cancelled';job.updatedAt=Date.now();await save(job);await notify(job,'RESULT',{posts:job.posts||[],error:'Đã dừng nhận kết quả. Nếu ChatGPT còn tạo ảnh, bạn có thể bấm Dừng ở tab đó.'});}return {ok:true};}
  if(!fromGPT)throw Error('Trang gửi yêu cầu không được phép.');
  const job=await getJob();
  if(!job||job.gptTab!==sender.tab.id||!['opening','running'].includes(job.status))return {ok:true,job:null,cancelled:true};
  if(m.type==='CLAIM'&&m.agentVersion!=='1.0.12'){await finish(job,'Tab ChatGPT đang dùng tiện ích cũ. Cập nhật tiện ích và tải lại cả trang Meta Assistant lẫn tab ChatGPT.');return {ok:false,error:'Phiên bản tiện ích trong tab ChatGPT chưa đồng bộ.'};}
  if(m.type==='CLAIM')return {ok:true,job:{id:job.id,nonce:job.nonce,input:{items:[job.input.items[job.currentIndex||0]],images:job.input.images},index:job.currentIndex||0,total:job.input.items.length,status:job.status}};
  if(m.nonce!==job.nonce||m.id!==job.id)throw Error('Lượt tạo không hợp lệ.');
  if(m.type==='START'){if(job.status!=='opening')throw Error('Lượt này đã bắt đầu, không gửi lại yêu cầu.');job.status='running';job.updatedAt=Date.now();await save(job);return {ok:true};}
  if(m.type==='PROGRESS'){job.updatedAt=Date.now();job.progress=String(m.text||'').slice(0,500);if(m.diagnostic)job.diagnostic=m.diagnostic;await save(job);await notify(job,'PROGRESS',{text:job.progress});return {ok:true};}
  if(m.type==='TEXT_RESULT'){const active=job.input.items[job.currentIndex||0];if(!active||m.key!==active.key)throw Error('Chỉ nhận bài đang được giao.');const input={...job.input,items:[active]};if(!input.items.length)throw Error('Không tìm thấy bài được giao.');const posts=P.parse(m.text,input);job.posts=[...job.posts.filter(post=>!posts.some(p=>p.key===post.key)),...posts];job.updatedAt=Date.now();await save(job);await notify(job,'PARTIAL',{posts:job.posts});return {ok:true,posts:job.posts};}
  if(m.type==='IMAGE_RESULT'){
    const post=job.posts.find(x=>x.key===m.key);if(m.key!==job.input.items[job.currentIndex||0]?.key)throw Error('Ảnh không thuộc bài đang tạo.');if(!post)throw Error('Không tìm thấy bài để gắn ảnh.');
    if(m.data&&(!/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(m.data)||m.data.length>600000))throw Error('Ảnh không hợp lệ hoặc quá lớn.');
    post.imageData=m.data||'';post.imageError=String(m.error||'').slice(0,500);job.updatedAt=Date.now();await save(job);await notify(job,'PARTIAL',{posts:job.posts});return {ok:true};
  }
  if(m.type==='COMMIT_POST'){const active=job.input.items[job.currentIndex||0],post=job.posts.find(p=>p.key===active?.key);if(!post||m.key!==active.key||job.input.images&&!post.imageData)throw Error('Bài hoặc ảnh chưa hoàn tất.');job.pendingCommit=post.key;job.reviewSaved='';await save(job);await chrome.storage.local.set({reviewOutbox:{id:job.id,webTab:job.webTab,posts:job.posts,updatedAt:Date.now()}});try{await chrome.tabs.update(job.webTab,{active:true});}catch{}await notify(job,'PARTIAL',{posts:job.posts,reviewKey:post.key});return {ok:true};}
  if(m.type==='NEXT_ITEM'){const active=job.input.items[job.currentIndex||0];if(!active||m.key!==active.key)throw Error('Bài không đúng thứ tự.');if(job.pendingCommit!==active.key||job.reviewSaved!==active.key){if(job.pendingCommit){try{await chrome.tabs.update(job.webTab,{active:true});}catch{}await notify(job,'PARTIAL',{posts:job.posts,reviewKey:job.pendingCommit});}return {ok:true,waiting:true};}job.currentIndex=(job.currentIndex||0)+1;job.pendingCommit='';job.reviewSaved='';await save(job);const next=job.input.items[job.currentIndex];if(next){try{await chrome.tabs.update(job.gptTab,{active:true});}catch{}}return {ok:true,input:next?{items:[next],images:job.input.images}:null,index:job.currentIndex,total:job.input.items.length};}
  if(m.type==='DONE'){if((job.currentIndex||0)<job.input.items.length)throw Error('Chưa lưu hết bài vào danh sách duyệt.');await finish(job);return {ok:true};}
  if(m.type==='FAILED'){await finish(job,String(m.error||'Không hoàn tất được lượt tạo.').slice(0,1000));return {ok:true};}
  return {ok:true};
}
// Tuần tự hoá để hai tab không cùng mở lượt mới hoặc ghi đè trạng thái.
let messages=Promise.resolve();
chrome.runtime.onMessage.addListener((message,sender,respond)=>{const task=messages.then(()=>handle(message,sender));messages=task.catch(()=>{});task.then(respond,e=>respond({ok:false,error:e.message}));return true;});
chrome.tabs.onRemoved.addListener(async tabId=>{const job=await getJob();if(job?.gptTab===tabId&&['opening','running'].includes(job.status))await finish(job,'Tab ChatGPT đã đóng. Các bài đã nhận vẫn được giữ trên web.');});
