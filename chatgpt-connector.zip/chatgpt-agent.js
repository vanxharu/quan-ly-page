/* Chỉ chạy công việc được giao cho tab này, không đọc các cuộc trò chuyện khác. */
(() => {
  const P=MetaAIProtocol;let working=false,job=null,lastPing=0;
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  async function message(type,extra={}){const r=await chrome.runtime.sendMessage({type,id:job?.id,nonce:job?.nonce,...extra});if(r?.ok===false)throw Error(r.error);if(r?.cancelled)throw Error('Đã dừng lượt tạo.');return r;}
  const visible=el=>!!el?.getClientRects().length;
  const editor=()=>[...document.querySelectorAll('#prompt-textarea,#mobile-composer-prompt,textarea,[contenteditable="true"][role="textbox"],div.ProseMirror')].find(visible);
  const button=(kind)=>[...document.querySelectorAll('button')].find(el=>visible(el)&&((kind==='send'&&(/^(send|gửi)(\s|$)/i.test(el.getAttribute('aria-label')||'')||el.dataset.testid==='send-button'))||(kind==='stop'&&(/^(stop|dừng)(\s|$)/i.test(el.getAttribute('aria-label')||'')||el.dataset.testid==='stop-button'))));
  const assistants=()=>[...document.querySelectorAll('[data-message-author-role="assistant"], [data-message-role="assistant"], [data-author="assistant"], [data-role="assistant"]')].filter(visible);
  const users=()=>[...document.querySelectorAll('[data-message-role="user"],[data-message-author-role="user"],[data-author="user"]')].filter(visible);
  const textOf=el=>(el.querySelector('.markdown,[data-message-content],[data-assistant-markdown-root]')||el).innerText?.trim()||'';
  async function progress(text){await message('PROGRESS',{text});lastPing=Date.now();}
  async function ping(){if(Date.now()-lastPing>20000)await progress('Đang chờ ChatGPT hoàn tất…');}
  async function waitEditor(){
    const end=Date.now()+240000;await progress('Nếu ChatGPT yêu cầu, hãy đăng nhập và hoàn tất kiểm tra trong tab này.');
    while(Date.now()<end){await ping();const el=editor();const login=[...document.querySelectorAll('button')].some(x=>visible(x)&&/^(đăng nhập|log in|sign in)$/i.test(x.innerText.trim()));if(el&&!el.disabled&&!login)return el;await sleep(1000);}throw Error('Chưa đăng nhập ChatGPT hoặc ô soạn chưa sẵn sàng.');
  }
  async function send(prompt){
    const el=await waitEditor();if((el.value||el.innerText||'').trim())throw Error('Ô soạn ChatGPT đang có nội dung. Giữ lại nội dung đó và tạo lượt mới sau.');
    prompt += '\n[Meta Assistant: '+job.id+'; mã nhận diện, không đưa vào bài viết hoặc ảnh.]';
    const count=assistants().length;
    el.focus();
    if(el.tagName==='TEXTAREA'){const setter=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,'value').set;setter.call(el,prompt);el.dispatchEvent(new Event('input',{bubbles:true}));}
    else{document.execCommand('insertText',false,prompt);el.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:prompt}));}
    const end=Date.now()+10000;let sendButton;
    while(Date.now()<end){sendButton=button('send');if(sendButton&&!sendButton.disabled)break;await sleep(300);}
    if(!sendButton||sendButton.disabled)throw Error('Không tìm thấy nút Gửi của ChatGPT. Yêu cầu đang được giữ trong ô soạn.');
    sendButton.click();return count; // Không tự gửi lại sau khi đã bấm Gửi.
  }
  async function waitAnswer(before,wantImage=false){
    const end=Date.now()+(wantImage?240000:180000);let previous='',stableSince=0;
    while(Date.now()<end){await ping();const user=users().at(-1);if(!user){await sleep(500);continue;}if(!user.innerText.includes(job.id))throw Error('Tab đã chuyển cuộc trò chuyện hoặc có tin nhắn khác. Đã dừng để không lấy nhầm kết quả.');const all=assistants();const last=all.at(-1);
      if(all.length>before&&last){const text=textOf(last);const imgs=[...last.querySelectorAll('img')].filter(img=>img.naturalWidth>=256&&img.naturalHeight>=256&&P.imageURL(img.currentSrc||img.src));const value=text+'|'+imgs.map(i=>i.currentSrc||i.src).join('|');
        if(value!==previous){previous=value;stableSince=Date.now();}
        if(!button('stop')&&Date.now()-stableSince>6000&&(wantImage?imgs.length:text.length))return {text,images:imgs.map(i=>i.currentSrc||i.src)};
        if(wantImage&&!button('stop')&&text&&Date.now()-stableSince>18000&&!imgs.length)throw Error('ChatGPT chưa trả ảnh. Có thể tài khoản chạm giới hạn, hoặc cần bạn thao tác trong tab.');
      }await sleep(1000);
    }throw Error('ChatGPT chưa hoàn tất trong thời gian chờ. Mở tab đó để kiểm tra; tiện ích không tự gửi lại yêu cầu.');
  }
  async function imageData(url){
    if(!P.imageURL(url))throw Error('Đường dẫn ảnh không được phép.');
    const response=await fetch(url,{credentials:'include'});if(!response.ok)throw Error('Không tải được ảnh ChatGPT.');
    const blob=await response.blob();if(!blob.type.startsWith('image/')||blob.size>15*1024*1024)throw Error('Ảnh quá lớn hoặc sai định dạng.');
    const bitmap=await createImageBitmap(blob),scale=Math.min(1,1024/Math.max(bitmap.width,bitmap.height));
    const canvas=new OffscreenCanvas(Math.max(1,Math.round(bitmap.width*scale)),Math.max(1,Math.round(bitmap.height*scale)));canvas.getContext('2d').drawImage(bitmap,0,0,canvas.width,canvas.height);bitmap.close();
    const small=await canvas.convertToBlob({type:'image/jpeg',quality:.78});
    const data=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(small);});
    if(data.length>600000)throw Error('Ảnh quá lớn để chuyển tự động. Tải ảnh từ ChatGPT rồi chọn ảnh trên web.');return data;
  }
  async function run(){
    if(working)return;working=true;
    try{const claimed=await chrome.runtime.sendMessage({type:'CLAIM'});if(!claimed?.job)return;job=claimed.job;
      await waitEditor();
      if(job.status==='running'||sessionStorage.getItem('meta-ai-job:'+job.id))throw Error('Tab ChatGPT đã được tải lại. Giữ các kết quả đã có và tạo lượt mới để tránh gửi lặp.');
      if(assistants().length||users().length)throw Error('Tab ChatGPT không phải cuộc trò chuyện mới. Đã dừng để giữ riêng các cuộc trò chuyện của bạn.');
      await message('START');
      sessionStorage.setItem('meta-ai-job:'+job.id,'started');
      await progress('Đang soạn nội dung…');const before=await send(P.prompt(job.input));const answer=await waitAnswer(before);const result=await message('TEXT_RESULT',{text:answer.text});
      if(job.input.images)for(let i=0;i<result.posts.length;i++){
        const post=result.posts[i];await progress(`Đang tạo ảnh ${i+1}/${result.posts.length}…`);
        try{const count=await send(P.imagePrompt(post));const generated=await waitAnswer(count,true);await message('IMAGE_RESULT',{key:post.key,data:await imageData(generated.images[0])});}
        catch(e){await message('IMAGE_RESULT',{key:post.key,error:e.message});if(/Đã dừng|Tab đã chuyển|Ô soạn ChatGPT|Không tìm thấy nút Gửi/.test(e.message))throw e;}
      }
      await message('DONE');
    }catch(e){if(job)await message('FAILED',{error:e.message}).catch(()=>{});}
    finally{working=false;}
  }
  run();let attempts=0;const timer=setInterval(()=>{if(!job&&!working&&attempts++<20)run();if(job||attempts>=20)clearInterval(timer);},1500);
})();
