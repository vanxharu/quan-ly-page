/* Chỉ chạy công việc được giao cho tab này, không đọc các cuộc trò chuyện khác. */
(() => {
  const P=MetaAIProtocol;let working=false,job=null,lastPing=0,stage='',step=0,expectedMarker='',expectedPrefix='',submittedUser=null,baselineUsers=[],baselineReplies=[],baselineTurns=[],baselineSignatures=new Set(),boundConversation='';
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  async function message(type,extra={}){const r=await chrome.runtime.sendMessage({type,id:job?.id,nonce:job?.nonce,...extra});if(r?.ok===false)throw Error(r.error);if(r?.cancelled)throw Error('Đã dừng lượt tạo.');return r;}
  const visible=el=>!!el?.getClientRects().length;
  const editor=()=>[...document.querySelectorAll('#prompt-textarea,#mobile-composer-prompt,textarea,[contenteditable="true"][role="textbox"],div.ProseMirror')].find(visible);
  const button=(kind)=>[...document.querySelectorAll('button')].find(el=>visible(el)&&((kind==='send'&&(/^(send|gửi)(\s|$)/i.test(el.getAttribute('aria-label')||'')||['send-button','composer-submit-button'].includes(el.dataset.testid)))||(kind==='stop'&&(/^(stop generating|stop streaming|dừng tạo|ngừng tạo|dừng phản hồi|stop|dừng)$/i.test(el.getAttribute('aria-label')||'')||el.dataset.testid==='stop-button'))));
  const assistants=()=>[...new Set([...document.querySelectorAll('[data-message-author-role="assistant"], [data-message-role="assistant"], [data-author="assistant"], [data-role="assistant"], article[data-turn="assistant"]')].map(el=>el.closest?.('[data-testid^="conversation-turn-"]')||el))].filter(visible);
  const users=()=>[...new Set([...document.querySelectorAll('[data-message-role="user"],[data-message-author-role="user"],[data-author="user"],article[data-turn="user"]')].map(el=>el.closest?.('[data-testid^="conversation-turn-"]')||el))].filter(visible);
  const userText=el=>[el?.textContent||'',el?.innerText||''].join('\n');
  const compact=text=>String(text||'').replace(/\s+/g,' ').trim();
  const matchesStep=el=>userText(el).includes(expectedMarker)||(el===submittedUser&&!baselineUsers.includes(el)&&compact(userText(el)).includes(expectedPrefix));
  const textOf=el=>(el.querySelector('.markdown,[data-message-content],[data-assistant-markdown-root]')||el).innerText?.trim()||'';
  const turns=()=>[...document.querySelectorAll('article[data-testid^="conversation-turn-"], [data-testid^="conversation-turn-"]')];
  const signature=el=>compact(userText(el))+'|'+[...el.querySelectorAll('img')].map(img=>img.currentSrc||img.src).join('|');
  function checkConversation(){const path=location.pathname;if(boundConversation&&path!==boundConversation)throw Error('Tab đã chuyển cuộc trò chuyện. Đã dừng để không lấy nhầm kết quả.');if(path.startsWith('/c/'))boundConversation=path;}
  function newReply(){return assistants().filter(el=>!baselineReplies.includes(el)&&!baselineSignatures.has(signature(el))).at(-1)||turns().filter(el=>!baselineTurns.includes(el)&&!userText(el).includes(expectedMarker)&&!users().some(u=>el===u||el.contains(u))&&!el.matches?.('[data-turn="user"]')&&!el.querySelector('[data-message-author-role="user"],[data-message-role="user"]')&&!baselineSignatures.has(signature(el))).at(-1);}
  async function progress(text){if(!/đang xử lý/i.test(text))stage=text;await message('PROGRESS',{text,diagnostic:{agentVersion:'1.0.10',step,users:users().length,replies:assistants().length,editorEmpty:!editorText(editor()||{}),generationVisible:!!button('stop')}});lastPing=Date.now();}
  async function ping(){if(Date.now()-lastPing>20000)await progress(stage?stage+' ChatGPT đang xử lý…':'Đang chờ ChatGPT hoàn tất…');}
  async function waitEditor(){
    let explained=false;
    while(true){await ping();const el=editor();const login=[...document.querySelectorAll('button')].some(x=>visible(x)&&/^(đăng nhập|log in|sign in)$/i.test(x.innerText.trim()));if(el&&!el.disabled&&!login)return el;if(!explained){await progress('Nếu ChatGPT yêu cầu, hãy đăng nhập và hoàn tất kiểm tra trong tab này.');explained=true;}await sleep(1000);}
  }
  const editorText=el=>(el.value||el.innerText||'').trim();
  const ownDraft=text=>/Bạn là trợ lý soạn nội dung Fanpage|Hãy TẠO MỘT ẢNH/.test(text)&&/\[Meta Assistant: ai-[a-zA-Z0-9_-]+(?::step-\d+)?;[^\]]*\]/.test(text);
  async function prepareEditor(){
    let emptySince=0,notice=false;
    while(true){await ping();const el=await waitEditor(),text=editorText(el);
      if(text){emptySince=0;
        if(ownDraft(text)){
          const key='recoveredMetaAssistantPrompts',previous=(await chrome.storage.local.get(key))[key]||[];
          await chrome.storage.local.set({[key]:[...previous,{text,at:Date.now(),jobId:job.id}].slice(-5)});
          el.focus();
          if(el.tagName==='TEXTAREA'){Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,'value').set.call(el,'');}
          else{const range=document.createRange();range.selectNodeContents(el);const selection=window.getSelection();selection.removeAllRanges();selection.addRange(range);document.execCommand('delete',false);}
          el.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'deleteContentBackward',data:null}));
          if(editorText(el))throw Error('Đã sao lưu prompt cũ nhưng chưa dọn được ô soạn. Xoá prompt cũ ở tab ChatGPT để tiếp tục lượt mới.');
          await progress('Đã sao lưu và dọn prompt Meta Assistant cũ. Đang chuẩn bị gửi từng bài…');
        }else if(!notice){await progress('Ô ChatGPT có nội dung bạn đang soạn. Hãy gửi hoặc cất nội dung đó; tiện ích đang chờ ô trống và sẽ tự tiếp tục.');notice=true;}
      }else{if(!emptySince)emptySince=Date.now();if(Date.now()-emptySince>=1500)return el;}
      await sleep(500);
    }
  }
  async function send(prompt){
    checkConversation();const el=await prepareEditor();
    expectedMarker=job.id+':step-'+(++step);
    expectedPrefix=compact(prompt).slice(0,160);submittedUser=null;
    const previousUser=users().at(-1);
    prompt = '[Meta Assistant: '+expectedMarker+'; mã nhận diện, không đưa vào bài viết hoặc ảnh.]\n'+prompt;
    baselineUsers=users();baselineReplies=assistants();baselineTurns=turns();baselineSignatures=new Set([...baselineReplies,...baselineTurns].map(signature));
    const count=baselineReplies.length;
    el.focus();
    if(el.tagName==='TEXTAREA'){const setter=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,'value').set;setter.call(el,prompt);el.dispatchEvent(new Event('input',{bubbles:true}));}
    else{document.execCommand('insertText',false,prompt);el.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:prompt}));}
    if(!(el.value||el.innerText||'').includes(expectedMarker))throw Error('Chưa điền được prompt vào ô soạn ChatGPT. Không gửi yêu cầu rỗng.');
    const end=Date.now()+10000;let sendButton;
    while(Date.now()<end){sendButton=button('send');if(sendButton&&!sendButton.disabled)break;await sleep(300);}
    if(!sendButton||sendButton.disabled)throw Error('Không tìm thấy nút Gửi của ChatGPT. Yêu cầu đang được giữ trong ô soạn.');
    sendButton.click();
    // A click is not proof of submission: wait for this exact step to appear as a user turn.
    let explained=false;
    while(true){await ping();checkConversation();const user=users().at(-1);if(user&&(userText(user).includes(expectedMarker)||(user!==previousUser&&compact(userText(user)).includes(expectedPrefix)))){submittedUser=user;await progress('ChatGPT đã nhận yêu cầu. Đang chờ kết quả…');return count;}
      if(!editorText(editor()||{})&&(button('stop')||newReply())){submittedUser=user||null;await progress('Đã xác nhận ChatGPT đang trả lời. Đang chờ kết quả…');return count;}
      if(!explained){await progress('Đang xác nhận ChatGPT đã nhận yêu cầu. Nếu prompt vẫn trong ô soạn, bấm Gửi tại tab ChatGPT; tiện ích sẽ tự tiếp tục.');explained=true;}
      await sleep(500);
    } // Never click Send again automatically for this step.
  }
  function responseAfterUser(before){
    const user=users().at(-1);if(!user||!matchesStep(user))return newReply()||null;
    // Generated-image cards may be siblings of the assistant message, inside the turn article.
    const turns=[...document.querySelectorAll('article[data-testid^="conversation-turn-"], [data-testid^="conversation-turn-"]')];
    const index=turns.findIndex(turn=>turn.contains(user));
    if(index>=0){const following=turns.slice(index+1).filter(turn=>!turn.contains(user));if(following.length)return following.at(-1);}
    const all=assistants();return all.length>before?all.at(-1):null;
  }
  async function waitAnswer(before,wantImage=false){
    let previous='',stableSince=0;
    while(true){await ping();checkConversation();const user=users().at(-1);if(user&&submittedUser&&user!==submittedUser&&!baselineUsers.includes(user)&&!matchesStep(user))throw Error('Có tin nhắn khác trong tab ChatGPT. Đã dừng để không lấy nhầm kết quả.');const last=responseAfterUser(before);
      if(last){const text=textOf(last);const imgs=[...last.querySelectorAll('img')].filter(img=>img.naturalWidth>=256&&img.naturalHeight>=256&&P.imageURL(img.currentSrc||img.src));const value=text+'|'+imgs.map(i=>i.currentSrc||i.src).join('|');
        if(value!==previous){previous=value;stableSince=Date.now();}
        if(!button('stop')&&Date.now()-stableSince>6000&&(wantImage?imgs.length:text.length))return {text,images:imgs.map(i=>i.currentSrc||i.src)};
      }await sleep(1000);
    }
  }
  async function imageData(url){
    if(!P.imageURL(url))throw Error('Đường dẫn ảnh không được phép.');
    const response=await fetch(url,{credentials:'include'});if(!response.ok)throw Error('Không tải được ảnh ChatGPT.');
    const blob=await response.blob();if(!blob.type.startsWith('image/')||blob.size>15*1024*1024)throw Error('Ảnh quá lớn hoặc sai định dạng.');
    const bitmap=await createImageBitmap(blob),scale=Math.min(1,1350/Math.max(bitmap.width,bitmap.height));
    const canvas=new OffscreenCanvas(Math.max(1,Math.round(bitmap.width*scale)),Math.max(1,Math.round(bitmap.height*scale)));canvas.getContext('2d').drawImage(bitmap,0,0,canvas.width,canvas.height);bitmap.close();
    // Preserve the portrait resolution and use the best JPEG quality that fits the transfer budget.
    const encode=async quality=>{const blob=await canvas.convertToBlob({type:'image/jpeg',quality});return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(blob);});};
    for(let size=0;size<5;size++){
      for(const quality of [.94,.9,.86,.82,.78,.74]){const data=await encode(quality);if(data.length<=600000)return data;}
      const copy=new OffscreenCanvas(canvas.width,canvas.height);copy.getContext('2d').drawImage(canvas,0,0);
      canvas.width=Math.max(1,Math.round(canvas.width*.85));canvas.height=Math.max(1,Math.round(canvas.height*.85));canvas.getContext('2d').drawImage(copy,0,0,canvas.width,canvas.height);
    }
    throw Error('Ảnh quá lớn để chuyển tự động. Tải ảnh gốc từ ChatGPT rồi chọn ảnh trên web.');
  }

  async function run(){
    if(working)return;working=true;
    try{const claimed=await chrome.runtime.sendMessage({type:'CLAIM',agentVersion:'1.0.10'});if(!claimed?.job)return;job=claimed.job;
      await waitEditor();
      if(job.status==='running'||sessionStorage.getItem('meta-ai-job:'+job.id))throw Error('Tab ChatGPT đã được tải lại. Giữ các kết quả đã có và tạo lượt mới để tránh gửi lặp.');
      if(assistants().length||users().length)throw Error('Tab ChatGPT không phải cuộc trò chuyện mới. Đã dừng để giữ riêng các cuộc trò chuyện của bạn.');
      await message('START');
      sessionStorage.setItem('meta-ai-job:'+job.id,'started');
      while(job.input){
        const i=job.index||0,total=job.total;const item=job.input.items[0];
        await progress(`Đang soạn nội dung bài ${i+1}/${total} · ${item.pageName}…`);
        const before=await send(P.prompt({...job.input,items:[item]}));
        const answer=await waitAnswer(before);
        const result=await message('TEXT_RESULT',{key:item.key,text:answer.text});
        const post=result.posts.find(p=>p.key===item.key);
        await progress(`Đã lưu nội dung bài ${i+1}/${total} · ${item.pageName}.`);
        if(job.input.images){
          await progress(`Đang tạo ảnh ${i+1}/${total} · ${item.pageName}…`);
          try{const count=await send(P.imagePrompt(post));const generated=await waitAnswer(count,true);await progress(`Đã nhận ảnh ${i+1}/${total}. Đang tải ảnh về bản nháp…`);const data=await imageData(generated.images[0]);await progress(`Đang chuyển bài và ảnh ${i+1}/${total} về trang duyệt…`);await message('IMAGE_RESULT',{key:post.key,data});}
          catch(e){await message('IMAGE_RESULT',{key:post.key,error:e.message});throw e;}
        }
        await message('COMMIT_POST',{key:item.key});
        await progress(`Đang lưu bài ${i+1}/${total} vào danh sách chờ duyệt · ${item.pageName}…`);
        let next;
        do{next=await message('NEXT_ITEM',{key:item.key});if(next.waiting){await ping();await sleep(2000);}}while(next.waiting);
        await progress(`Đã lưu bài ${i+1}/${total} vào danh sách chờ duyệt · ${item.pageName}.`);
        job.input=next.input;job.index=next.index;job.total=next.total;
      }
      await message('DONE');
    }catch(e){if(job)await message('FAILED',{error:e.message}).catch(()=>{});}
    finally{working=false;}
  }
  run();let attempts=0;const timer=setInterval(()=>{if(!job&&!working&&attempts++<20)run();if(job||attempts>=20)clearInterval(timer);},1500);
})();
